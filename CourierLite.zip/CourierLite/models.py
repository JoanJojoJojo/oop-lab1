from __future__ import annotations
from dataclasses import dataclass, field
from typing import Tuple

class Identifiable:
    """Mixin that requires get_id() -> str"""
    def get_id(self) -> str:
        raise NotImplementedError

class Printable:
    """Mixin that requires to_row() -> tuple"""
    def to_row(self) -> Tuple:
        raise NotImplementedError

@dataclass
class Hub(Identifiable, Printable):
    hub_id: str
    hub_name: str
    campus: str

    def get_id(self) -> str:
        return self.hub_id

    def to_row(self) -> Tuple:
        return (self.hub_id, self.hub_name, self.campus)

    def __repr__(self) -> str:
        return f"Hub({self.hub_id!r}, {self.hub_name!r}, {self.campus!r})"

@dataclass
class Parcel(Identifiable, Printable):
    parcel_id: str
    recipient: str
    priority: str  # EXPRESS|NORMAL
    hub_id: str
    destination: str
    weight_kg: float
    # preserve original CSV order index for deterministic ordering
    _csv_index: int = field(default=0, repr=False, compare=False)

    def get_id(self) -> str:
        return self.parcel_id

    def to_row(self) -> Tuple:
        return (self.parcel_id, self.recipient, self.priority, self.hub_id, self.destination, self.weight_kg)

    def __repr__(self) -> str:
        return f"Parcel({self.parcel_id!r}, {self.priority!r}, hub={self.hub_id!r}, w={self.weight_kg})"

@dataclass
class Rider(Identifiable, Printable):
    rider_id: str
    name: str
    max_load_kg: float
    home_hub_id: str

    def get_id(self) -> str:
        return self.rider_id

    def to_row(self) -> Tuple:
        return (self.rider_id, self.name, self.max_load_kg, self.home_hub_id)

    def __repr__(self) -> str:
        return f"Rider({self.rider_id!r}, {self.name!r}, max={self.max_load_kg}, hub={self.home_hub_id!r})"

# Bonus/G: PickupPoint base + three personalized subclasses
@dataclass
class PickupPoint(Identifiable, Printable):
    pickup_id: str
    hub_id: str
    label: str
    base_priority_bias: int = 0

    def get_id(self) -> str:
        return self.pickup_id

    def to_row(self) -> Tuple:
        return (self.pickup_id, self.label, self.hub_id, self.base_priority_bias)

    def __repr__(self) -> str:
        return f"PickupPoint({self.pickup_id!r}, hub={self.hub_id!r}, bias={self.base_priority_bias})"

# Student should pick unique names; here's three custom ones:
@dataclass
class CornerKiosk(PickupPoint):
    base_priority_bias: int = 1

@dataclass
class VaultLocker(PickupPoint):
    base_priority_bias: int = 0

@dataclass
class FrontDesk(PickupPoint):
    base_priority_bias: int = -1
