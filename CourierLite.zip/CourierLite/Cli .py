# courierlite/cli.py
from __future__ import annotations
import argparse
import logging
import os
import logging.config
from .models import logging as module_logger
from .engine import HubRepo, RiderRepo, ParcelRepo, load_hubs, load_riders, load_parcels, assign_parcels
from .engine import express_then_normal, heavy_first

 
 
 
LOGGING_CONF = os.path.join(os.path.dirname(__file__), "logging.conf")
class pickup_load_iterator:
    def __init__(self, pickups):
        self.pickups = pickups

    def __iter__(self):
        for hub_id, parcel_ids in self.pickups.items():
            for pid in parcel_ids:
                yield hub_id, pid
def load_pickups(pickups_csv):
    pickups = {}
    with open(pickups_csv, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(",")
            hub_id = parts[0].strip()
            parcel_ids = [p.strip() for p in parts[1:]]
            pickups[hub_id] = parcel_ids
    return pickups
def default_pickups_for_hubs(hubs_repo):
    pickups = {}
    for hub in hubs_repo.all():
        pickups[hub.hub_id] = []
    return pickups
class RiderLoadIterator:
    def __init__(self, rider, parcels):
        self.rider = rider
        self.parcels = parcels

    def __iter__(self):
        for parcel in self.parcels:
            yield parcel
            
            
def setup_logging():
    if os.path.exists(LOGGING_CONF):
        logging.config.fileConfig(LOGGING_CONF, disable_existing_loggers=False)
    else:
        logging.basicConfig(level=logging.INFO)
        
        

def format_table_row(cols, widths):
    cells = []
    for val, w in zip(cols, widths):
        s = str(val)
        if len(s) > w - 1:
            s = s[:w-3] + "..."
        cells.append(s.ljust(w))
    return " | ".join(cells)

def print_assignments(assignments, riders_repo):
    rows = []
    widths = [12, 12, 10, 40]
    header = format_table_row(["rider_id", "total_load", "#parcels", "first_3_destinations"], widths)
    print(header)
    print("-" * len(header))
    for rider in sorted(riders_repo.all(), key=lambda r: r.rider_id):
        pid = rider.rider_id
        parcels = assignments.get(pid, [])
        total_load = sum(p.weight_kg for p in parcels)
        first3 = ", ".join([p.destination for p in parcels[:3]])
        print(format_table_row([pid, f"{total_load:.2f}", len(parcels), first3], widths))

def main(argv=None):
    setup_logging()
    logger = logging.getLogger(__name__)
    parser = argparse.ArgumentParser(prog="courierlite")
    parser.add_argument("--hubs", required=True)
    parser.add_argument("--parcels", required=True)
    parser.add_argument("--riders", required=True)
    parser.add_argument("--assign", action="store_true")
    parser.add_argument("--threshold", type=float, default=2.0)
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--rider", type=str, default=None)
    parser.add_argument("--pickups", type=str, default=None)
    args = parser.parse_args(argv)

    hubs = HubRepo()
    riders = RiderRepo()
    parcels = ParcelRepo()

    load_hubs(args.hubs, hubs)
    load_riders(args.riders, riders)
    load_parcels(args.parcels, parcels)

    pickups = {}
    if args.pickups:
        pickups = load_pickups(args.pickups)
    if not pickups:
        pickups = default_pickups_for_hubs(hubs)

    if args.assign:
        assignments, unassigned = assign_parcels(hubs, riders, parcels, pickups=pickups)
        print_assignments(assignments, riders)
        print("\nUnassigned parcels:")
        if unassigned:
            for pid in sorted(unassigned):
                print(pid)
        else:
            print("(none)")

        if args.preview:
            # show preview of generator ordering for one rider or for each rider if none specified
            threshold = args.threshold
            for rider in sorted(riders.all(), key=lambda r: r.rider_id):
                if args.rider and rider.rider_id != args.rider:
                    continue
                assigned = assignments.get(rider.rider_id, [])
                print(f"\nPreview for rider {rider.rider_id} (threshold {threshold}kg):")
                
                
                
                
                pipeline = heavy_first(threshold)(express_then_normal(assigned))
                for idx, p in enumerate(pipeline, start=1):
                    print(f" {idx}. {p.parcel_id} [{p.priority}] {p.weight_kg}kg -> {p.destination}")

if __name__ == "__main__":
    main() 
class TestCourierLiteCore(unittest.TestCase):
    def __init__(self,tttttempdir):
        self.tempdir = tempfile.TemporaryDirectory()
        self.base = self.tempdir.name

        bad_csv = os.path.join(self.base, "bad_parcels.csv")
        self.bad_csv = bad_csv
        self.parcels_repo = ParcelRepo()
        with open(bad_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["parcel_id","recipient","priority","hub_id","destination","weight_kg"])
            writer.writerow(["P1","X","EXPRESS","H1","Room 1","2.0"])
        
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.base = self.tempdir.name
 
    
        bad_csv = os.path.join(self.base, "bad_parcels.csv")
        self.bad_csv = bad_csv
        self.parcels_repo = ParcelRepo()
        with open(bad_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["parcel_id","recipient","priority","hub_id","destination","weight_kg"])
            writer.writerow(["P1","X","EXPRESS","H1","Room 1","2.0"])
            writer.writerow(["","MissingId","NORMAL","H1","Room","1.0"])
