from __future__ import annotations
import csv
import logging
from typing import Dict, List, Set, Tuple, Iterable, Callable
from collections import defaultdict, deque

from .models import Hub, Parcel, Rider, PickupPoint, CornerKiosk, VaultLocker, FrontDesk

logger = logging.getLogger(__name__)

# Custom exceptions
class DataFormatError(Exception):
    pass

class DomainRuleError(Exception):
    pass

# --- Repositories ---
class BaseRepo:
    def __init__(self):
        self._data: Dict[str, object] = {}

    def add(self, obj):
        self._data[obj.get_id()] = obj

    def get(self, id_: str):
        return self._data.get(id_)

    def all(self) -> List:
        return list(self._data.values())

    def exists(self, id_: str) -> bool:
        return id_ in self._data

    def ids(self) -> Set[str]:
        return set(self._data.keys())

class HubRepo(BaseRepo): pass
class ParcelRepo(BaseRepo): pass
class RiderRepo(BaseRepo): pass

# --- CSV loaders with validation ---
def _normalize_priority(value: str) -> str:
    if value is None:
        raise DataFormatError("Missing priority")
    val = value.strip().upper()
    if val not in ("EXPRESS", "NORMAL"):
        raise DataFormatError(f"Invalid priority '{value}'")
    return val

def load_hubs(path: str, hubs: HubRepo) -> None:
    with open(path, newline='', encoding='utf-8') as fh:
        reader = csv.DictReader(fh)
        idx = 0
        for row in reader:
            idx += 1
            try:
                hub_id = row.get("hub_id") or row.get("id") or None
                if not hub_id:
                    raise DataFormatError("Missing hub_id")
                hub = Hub(hub_id=str(hub_id).strip(), hub_name=str(row.get("hub_name","")).strip(), campus=str(row.get("campus","")).strip())
                hubs.add(hub)
            except Exception as e:
                logger.warning("Skipping malformed hub row %d: %s", idx, e)

def load_riders(path: str, riders: RiderRepo) -> None:
    with open(path, newline='', encoding='utf-8') as fh:
        reader = csv.DictReader(fh)
        idx = 0
        for row in reader:
            idx += 1
            try:
                rider_id = row.get("rider_id") or None
                if not rider_id:
                    raise DataFormatError("Missing rider_id")
                name = row.get("name","").strip()
                max_load_kg = float(row.get("max_load_kg"))
                home_hub = row.get("home_hub_id") or row.get("home_hub") or ""
                rider = Rider(rider_id=str(rider_id).strip(), name=name, max_load_kg=float(max_load_kg), home_hub_id=str(home_hub).strip())
                riders.add(rider)
            except Exception as e:
                logger.warning("Skipping malformed rider row %d: %s", idx, e)

def load_parcels(path: str, parcels: ParcelRepo) -> None:
    with open(path, newline='', encoding='utf-8') as fh:
        reader = csv.DictReader(fh)
        idx = 0
        for row in reader:
            idx += 1
            try:
                parcel_id = row.get("parcel_id") or None
                if not parcel_id:
                    raise DataFormatError("Missing parcel_id")
                recipient = row.get("recipient","").strip()
                priority = _normalize_priority(row.get("priority",""))
                hub_id = (row.get("hub_id") or row.get("hub") or "").strip()
                destination = row.get("destination","").strip()
                weight_kg = float(row.get("weight_kg") or row.get("weight_kg".replace("_","").strip()) or row.get("weight_kg","0"))
                parcel = Parcel(parcel_id=str(parcel_id).strip(), recipient=recipient, priority=priority, hub_id=hub_id, destination=destination, weight_kg=float(weight_kg), _csv_index=idx)
                parcels.add(parcel)
            except Exception as e:
                logger.warning("Skipping malformed parcel row %d: %s", idx, e)

# --- Pickups integration for bonus ---
def load_pickups(path: str) -> Dict[str, PickupPoint]:
    pickups: Dict[str, PickupPoint] = {}
    try:
        with open(path, newline='', encoding='utf-8') as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                pid = row.get("pickup_id")
                if not pid:
                    logger.warning("Skipping malformed pickup row (missing id)")
                    continue
                label = row.get("label","").strip()
                hub_id = row.get("hub_id","").strip()
                bias = int(row.get("base_priority_bias","0"))
                pp = PickupPoint(pickup_id=str(pid).strip(), hub_id=hub_id, label=label, base_priority_bias=bias)
                pickups[pp.pickup_id] = pp
    except FileNotFoundError:
        logger.info("No pickups.csv found; will instantiate defaults at runtime.")
    except Exception as e:
        logger.warning("Error loading pickups: %s", e)
    return pickups

def default_pickups_for_hubs(hubs: HubRepo) -> Dict[str, PickupPoint]:
    """Create one of each custom pickup attached to the first existing hub(s)."""
    pickups: Dict[str, PickupPoint] = {}
    hub_ids = list(hubs.ids()) or ["H_DEFAULT"]
    # To keep deterministic ordering, iterate hub_ids
    for i, hid in enumerate(hub_ids):
        # generate unique pickup ids
        pk1 = CornerKiosk(pickup_id=f"KIOSK_{i+1}", hub_id=hid, label=f"CornerKiosk-{hid}")
        pk2 = VaultLocker(pickup_id=f"VAULT_{i+1}", hub_id=hid, label=f"VaultLocker-{hid}")
        pk3 = FrontDesk(pickup_id=f"DESK_{i+1}", hub_id=hid, label=f"FrontDesk-{hid}")
        pickups[pk1.pickup_id] = pk1
        pickups[pk2.pickup_id] = pk2
        pickups[pk3.pickup_id] = pk3
    return pickups

def extract_pickup_id_from_destination(dest: str) -> str | None:
    # token format: "PICKUP:<pickup_id>" anywhere in destination
    if not dest:
        return None
    token = "PICKUP:"
    if token in dest:
        after = dest.split(token, 1)[1]
        # take the next token up to whitespace or comma
        pid = after.split()[0].strip().strip(",;")
        return pid or None
    return None

# --- Iterators & generators ---
class RiderLoadIterator:
    """Iterate parcels assigned to a rider and yield (parcel_id, weight_kg, cumulative_kg)"""
    def __init__(self, rider: Rider, parcels: List[Parcel]):
        self.rider = rider
        self.parcels = parcels

    def __iter__(self):
        cum = 0.0
        for p in self.parcels:
            cum += p.weight_kg
            yield (p.parcel_id, p.weight_kg, cum)

def express_then_normal(parcels_iter: Iterable[Parcel]):
    """Yield EXPRESS then NORMAL preserving order within each priority group."""
    express = []
    normal = []
    for p in parcels_iter:
        if p.priority.upper() == "EXPRESS":
            express.append(p)
        else:
            normal.append(p)
    for p in express:
        yield p
    for p in normal:
        yield p

def heavy_first(threshold_kg: float) -> Callable[[Iterable[Parcel]], Iterable[Parcel]]:
    """Return a function that when given parcel iterable will yield >= threshold first, then rest."""
    def _gen(parcels_iter: Iterable[Parcel]):
        heavy = []
        light = []
        for p in parcels_iter:
            if p.weight_kg >= threshold_kg:
                heavy.append(p)
            else:
                light.append(p)
        for p in heavy:
            yield p
        for p in light:
            yield p
    return _gen

# --- Assignment logic ---
def assign_parcels(hubs: HubRepo, riders: RiderRepo, parcels: ParcelRepo, pickups: Dict[str, PickupPoint] | None = None
                  ) -> Tuple[Dict[str, List[Parcel]], Set[str]]:
    """
    Assign parcels to riders according to rules:
    - rider only takes parcels from their home_hub_id
    - don't exceed max_load_kg
    - EXPRESS before NORMAL (CSV order preserved within group)
    - round-robin among riders at same hub by rider_id ascending
    - pickups bias: when same priority compare pickup base_priority_bias (higher preferred)
    Returns assignments dict and set of unassigned parcel_ids
    """
    pickups = pickups or {}
    # group riders by hub
    riders_by_hub: Dict[str, List[Rider]] = defaultdict(list)
    for r in sorted(riders.all(), key=lambda r: r.rider_id):
        riders_by_hub[r.home_hub_id].append(r)

    # group parcels by hub preserving CSV order
    parcels_by_hub: Dict[str, List[Parcel]] = defaultdict(list)
    for p in sorted(parcels.all(), key=lambda p: p._csv_index):
        parcels_by_hub[p.hub_id].append(p)

    assignments: Dict[str, List[Parcel]] = {r.get_id(): [] for r in riders.all()}
    load_by_rider: Dict[str, float] = {r.get_id(): 0.0 for r in riders.all()}
    unassigned: Set[str] = set()

    # For deterministic round-robin, maintain index pointers per hub
    rr_index: Dict[str, int] = {hub: 0 for hub in riders_by_hub.keys()}

    for hub_id, hub_parcels in parcels_by_hub.items():
        hub_riders = riders_by_hub.get(hub_id, [])
        if not hub_riders:
            # no riders at this hub - all parcels unassigned
            for p in hub_parcels:
                unassigned.add(p.parcel_id)
            continue

        # create ordering: EXPRESS then NORMAL (preserve csv order), but apply pickup bias for tie-breaking
        # stable sort key: priority_group, -pickup_bias, csv_index
        def pickup_bias(p: Parcel) -> int:
            pid = extract_pickup_id_from_destination(p.destination)
            if pid:
                pp = pickups.get(pid)
                if pp:
                    return pp.base_priority_bias
                else:
                    logger.warning("Unknown pickup id %s in parcel %s; ignoring bias", pid, p.parcel_id)
            return 0

        # First partition by priority preserving CSV order (we already preserved CSV by csv_index)
        express = [p for p in hub_parcels if p.priority.upper() == "EXPRESS"]
        normal = [p for p in hub_parcels if p.priority.upper() == "NORMAL"]

        # for each group apply stable sorting by -bias then csv_index to prefer higher bias within same priority
        def order_group(group: List[Parcel]) -> List[Parcel]:
            # stable sort using tuple(-bias, csv_index). Python sort is stable so earlier csv_index preserved among equal keys.
            return sorted(group, key=lambda p: (-pickup_bias(p), p._csv_index))

        ordered = order_group(express) + order_group(normal)

        # Prepare deque of riders for easy rotation; but we need persistent rr_index across parcels
        rider_ids_sorted = [r.rider_id for r in hub_riders]

        for p in ordered:
            assigned = False
            # start from rr_index for this hub to ensure round-robin
            start = rr_index.get(hub_id, 0) % len(rider_ids_sorted)
            # try all riders once in round-robin fashion
            for offset in range(len(rider_ids_sorted)):
                idx = (start + offset) % len(rider_ids_sorted)
                rider_id = rider_ids_sorted[idx]
                rider = riders.get(rider_id)
                if rider is None:
                    continue
                current_load = load_by_rider[rider_id]
                if current_load + p.weight_kg <= rider.max_load_kg:
                    assignments[rider_id].append(p)
                    load_by_rider[rider_id] = current_load + p.weight_kg
                    assigned = True
                    # next parcel round-robin should start from next rider to balance
                    rr_index[hub_id] = (idx + 1) % len(rider_ids_sorted)
                    break
                # else try next rider
            if not assigned:
                unassigned.add(p.parcel_id)
                # do not advance rr_index when unassigned
    return assignments, unassigned
