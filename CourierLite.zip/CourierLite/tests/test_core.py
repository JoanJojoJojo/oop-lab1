
# courierlite/tests/test_core.py
import io
import unittest
import csv
from models import Parcel, Rider
from engine import (ParcelRepo, RiderRepo, HubRepo,load_parcels, load_riders, load_hubs,assign_parcels, RiderLoadIterator)
import tempfile
import os

class TestCourierLiteCore(unittest.TestCase):
    def setUp(self):
    
        self.tempdir = tempfile.TemporaryDirectory()
        self.base = self.tempdir.name

        hubs_csv = os.path.join(self.base, "hubs.csv")
        with open(hubs_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["hub_id","hub_name","campus"])
            writer.writerow(["H1","Main Hub","North Campus"])

        riders_csv = os.path.join(self.base, "riders.csv")
        with open(riders_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["rider_id","name","max_load_kg","home_hub_id"])
            writer.writerow(["R1","Alice","5.0","H1"])
            writer.writerow(["R2","Bob","5.0","H1"])

        parcels_csv = os.path.join(self.base, "parcels.csv")
        with open(parcels_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["parcel_id","recipient","priority","hub_id","destination","weight_kg"])
            # EXPRESS parcels first (CSV order)
            writer.writerow(["P1","X","EXPRESS","H1","Room 100","2.0"])
            writer.writerow(["P2","Y","EXPRESS","H1","Room 200","2.0"])
            # NORMAL parcels
            writer.writerow(["P3","Z","NORMAL","H1","Room 3","3.0"])
            # overweight for any single rider (but fits combined distribution)
            writer.writerow(["P4","W","NORMAL","H1","Room 4","4.5"])

        self.hubs_csv = hubs_csv
        self.riders_csv = riders_csv
        self.parcels_csv = parcels_csv

    def tearDown(self):
        self.tempdir.cleanup()

    def test_csv_parsing_and_malformed_skip(self):
        # introduce a malformed row
        parcels_repo = ParcelRepo()
        # manually append a bad CSV file with missing parcel_id
        bad_csv = os.path.join(self.base, "bad_parcels.csv")
        with open(bad_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["parcel_id","recipient","priority","hub_id","destination","weight_kg"])
            writer.writerow(["P1","X","EXPRESS","H1","Room 1","2.0"])
            writer.writerow(["","MissingId","NORMAL","H1","Room","1.0"])  # malformed
        # load and ensure malformed is skipped and one good present
        load_parcels(bad_csv, parcels_repo)
        ids = parcels_repo.ids()
        self.assertIn("P1", ids)
        self.assertNotIn("", ids)
class TestAssignmentLogic(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.base = self.tempdir.name

        hubs_csv = os.path.join(self.base, "hubs.csv")
        with open(hubs_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["hub_id","hub_name","campus"])
            writer.writerow(["H1","Main Hub","North Campus"])

        riders_csv = os.path.join(self.base, "riders.csv")
        with open(riders_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["rider_id","name","max_load_kg","home_hub_id"])
            writer.writerow(["R1","Alice","5.0","H1"])
            writer.writerow(["R2","Bob","5.0","H1"])

        parcels_csv = os.path.join(self.base, "parcels.csv")
        with open(parcels_csv, "w", newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh)
            writer.writerow(["parcel_id","recipient","priority","hub_id","destination","weight_kg"])
          
          
          
          
            writer.writerow(["P1","X","express","H1","Room 100","2.0"])
            writer.writerow(["P2","Y","EXPRESS","H1","Room 200","2.0"])
            # NORMAL parcels
            writer.writerow(["P3","Z","NORMAL","H1","Room 3","3.0"])
            # overweight for any single rider (but fits combined distribution)
            writer.writerow(["P4","W","NORMAL","H1","Room 4","4.5"])

        self.hubs_csv = hubs_csv
        self.riders_csv = riders_csv
        self.parcels_csv = parcels_csv 
    
    
    def test_assignment_respects_capacity_and_round_robin(self):
        hubs = HubRepo()
        riders = RiderRepo()
        parcels = ParcelRepo()
        load_hubs(self.hubs_csv, hubs)
        load_riders(self.riders_csv, riders)
        load_parcels(self.parcels_csv, parcels)

        assignments, unassigned = assign_parcels(hubs, riders, parcels)
        # total loads should not exceed rider max
        for rider_id, plist in assignments.items():
            total = sum(p.weight_kg for p in plist)
            rider = riders.get(rider_id)
            self.assertLessEqual(total, rider.max_load_kg + 1e-6)

        # Check EXPRESS priority assignment: P1 and P2 should be assigned before P3 considered
        all_assigned = {p.get_id() for plist in assignments.values() for p in plist}
        self.assertIn("P1", all_assigned)
        self.assertIn("P2", all_assigned)

        # P4 weight 4.5 is large; may remain unassigned if no single rider can take it
        self.assertTrue("P4" in unassigned or any(p.get_id()=="P4" for plist in assignments.values() for p in plist))

    def test_rider_load_iterator_cumulative(self):
        # create parcels and rider
        p1 = Parcel("PX1","A","NORMAL","H1","dest", 1.0, _csv_index=1)
        p2 = Parcel("PX2","B","NORMAL","H1","dest", 2.0, _csv_index=2)
        rider = Rider("R9","Z",10.0,"H1")
        it = RiderLoadIterator(rider, [p1,p2])
        cum = 0.0
        items = list(it)
        self.assertEqual(items[0], ("PX1", 1.0, 1.0))
        self.assertEqual(items[1], ("PX2", 2.0, 3.0))

if __name__ == "__main__":
    unittest.main()
